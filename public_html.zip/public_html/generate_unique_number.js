// Function to generate a unique 5-digit number
function generateUniqueNumber() {
    // Generate a random 5-digit number
    return Math.floor(10000 + Math.random() * 90000);
}
